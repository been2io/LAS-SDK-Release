//
//  LASRole.h
//  LAS
//
//  Created by Sun Jin on 6/23/14.
//  Copyright (c) 2014 iLegendsoft. All rights reserved.
//

#import "LASObject.h"
#import "LASSubclassing.h"

@class LASQuery;

/*!
 Represents a Role on the LAS server. LASRoles represent groupings of LASUsers for the purposes of granting permissions (e.g. specifying a LASACL for a LASObject). Roles are specified by their sets of child users and child roles, all of which are granted any permissions that the parent role has.<br>
 <br>
 Roles must have a name (which cannot be changed after creation of the role), and must specify an ACL.
 */
@interface LASRole : LASObject <LASSubclassing>

#pragma mark Creating a New Role

/** @name Creating a New Role */

/*!
 Constructs a new LASRole with the given name. If no default ACL has been specified, you must provide an ACL for the role.
 
 @param name The name of the Role to create.
 */
- (id)initWithName:(NSString *)name;

/*!
 Constructs a new LASRole with the given name.
 
 @param name The name of the Role to create.
 @param acl The ACL for this role. Roles must have an ACL.
 */
- (id)initWithName:(NSString *)name acl:(LASACL *)acl;

/*!
 Constructs a new LASRole with the given name. If no default ACL has been specified, you must provide an ACL for the role.
 
 @param name The name of the Role to create.
 */
+ (instancetype)roleWithName:(NSString *)name;

/*!
 Constructs a new LASRole with the given name.
 
 @param name The name of the Role to create.
 @param acl The ACL for this role. Roles must have an ACL.
 */
+ (instancetype)roleWithName:(NSString *)name acl:(LASACL *)acl;

#pragma mark -
#pragma mark Role-specific Properties

/** @name Role-specific Properties */

/*!
 Gets or sets the name for a role. This value must be set before the role has been saved to the server, and cannot be set once the role has been saved.<br>
 <br>
 A role's name can only contain alphanumeric characters, _, -, and spaces.
 */
@property (nonatomic, copy) NSString *name;

/*!
 Gets the LASRelation for the LASUsers that are direct children of this role. These users are granted any privileges that this role has been granted (e.g. read or write access through ACLs). You can add or remove users from the role through this relation.
 */
@property (nonatomic, readonly, strong) LASRelation *users;

/*!
 Gets the LASRelation for the LASRoles that are direct children of this role. These roles' users are granted any privileges that this role has been granted (e.g. read or write access through ACLs). You can add or remove child roles from this role through this relation.
 */
@property (nonatomic, readonly, strong) LASRelation *roles;

#pragma mark -
#pragma mark Querying for Roles

/** @name Querying for Roles */

/*!
 Creates a query for LASRole objects.
 */
+ (LASQuery *)query;

@end
