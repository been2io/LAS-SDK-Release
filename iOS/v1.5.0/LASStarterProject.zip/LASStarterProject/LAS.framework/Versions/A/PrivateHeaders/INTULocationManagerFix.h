//
//  INTULocationManagerFix.h
//  LAS
//
//  Created by Sun Jin on 11/5/14.
//  Copyright (c) 2014 iLegendsoft. All rights reserved.
//

#import "LAS_INTULocationManager.h"

#ifndef LAS_INTULocationManagerFix_h
#define LAS_INTULocationManagerFix_h

typedef LAS_INTULocationManager INTULocationManager;

#endif
