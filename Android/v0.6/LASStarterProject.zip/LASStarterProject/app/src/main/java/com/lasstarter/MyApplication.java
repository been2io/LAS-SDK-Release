package com.lasstarter;

import android.app.Application;
import as.leap.LASConfig;

public class MyApplication extends Application {

    public static final String API_KEY = "your api key";

    public static final String REST_KEY = "your rest key";

    @Override
    public void onCreate() {
        super.onCreate();

        LASConfig.setLogLevel(LASConfig.LOG_LEVEL_ERROR);
        LASConfig.initialize(this, API_KEY, REST_KEY);
    }
}
